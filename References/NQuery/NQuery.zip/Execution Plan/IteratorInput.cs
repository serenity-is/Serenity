using System;

namespace NQuery.Runtime.ExecutionPlan
{
	public sealed class IteratorInput
	{
		public int SourceIndex;
	}
}
