using System;

namespace NQuery.Runtime.ExecutionPlan
{
	public sealed class RuntimeComputedValueOutput : RuntimeValueOutput
	{
		public RuntimeExpression Expression;
	}
}