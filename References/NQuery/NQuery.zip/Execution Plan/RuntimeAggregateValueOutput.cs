using System;

namespace NQuery.Runtime.ExecutionPlan
{
	public sealed class RuntimeAggregateValueOutput : RuntimeValueOutput
	{
		public IAggregator Aggregator;
		public RuntimeExpression Argument;
	}
}