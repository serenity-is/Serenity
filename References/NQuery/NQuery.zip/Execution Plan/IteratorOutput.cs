using System;

namespace NQuery.Runtime.ExecutionPlan
{
	public sealed class IteratorOutput
	{
		public int SourceIndex;
		public int TargetIndex;
	}
}