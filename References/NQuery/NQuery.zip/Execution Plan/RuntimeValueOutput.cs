using System;

namespace NQuery.Runtime.ExecutionPlan
{
	public class RuntimeValueOutput
	{
		public int TargetIndex;
	}
}