using System;

namespace NQuery.Runtime.ExecutionPlan
{
	public class RuntimeColumnValueOutput : RuntimeValueOutput
	{
		public ColumnBinding ColumnBinding;
	}
}