using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("NQuery")]
[assembly: AssemblyDescription("Query and Expression Evaluation Engine")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: NeutralResourcesLanguage("en-US")]

[assembly: InternalsVisibleTo("NQuery.Tests, PublicKey=002400000480000094000000060200000024000052534131000400000100010011ac4f1849d3a52753d867ab61d7c54b9976697dbcb85c702f736de4e6d9ef37da20f09a4cded2a3e32aae5723cfbdf745db09596349950c407c120487ba117ad1d4816a1a6d75c5bb6d777070bad14b5d285be2462c6de4463988ef652c02cffe372e74589c7a0ff3d0f4466b48b6da552d3f53356bb25a39ca59ff2cc3c0bf")]
