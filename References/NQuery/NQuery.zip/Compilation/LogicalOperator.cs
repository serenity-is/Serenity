using System;

namespace NQuery.Compilation
{
	public enum LogicalOperator
	{
		And,
		Or
	}
}