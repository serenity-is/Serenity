using System;

namespace NQuery.Compilation
{
	public class JoinOrder
	{
		public Join[] Joins;
		public ExpressionNode[] UnusedConditions;
	}
}