using System;

namespace NQuery.Compilation
{
	public delegate object CompiledExpressionDelegate(object[] args);
}