namespace NQuery.Compilation
{
	public enum CastingOperatorType
	{
		Implicit = 0x0001,
		Explicit = 0x0002
	}
}