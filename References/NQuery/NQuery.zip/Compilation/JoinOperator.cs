namespace NQuery.Compilation
{
	public enum JoinOperator
	{
		None,
		Equal,
		Less,
		LessOrEqual,
		Greater,
		GreaterOrEqual
	}
}