using System;

namespace NQuery.Compilation
{
	public sealed class ILParameterDeclaration
	{
		public int Index;
		public object Value;
		public Type Type;
	}
}