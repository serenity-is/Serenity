namespace NQuery.Compilation
{
	public enum JoinType
	{
		Inner,
		LeftOuter,
		RightOuter,
		FullOuter
	}
}