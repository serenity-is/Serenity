namespace NQuery.Compilation
{
	public enum BinaryQueryOperator
	{
		Union,
		UnionAll,
		Intersect,
		Except
	}
}