namespace NQuery.Compilation
{
	public abstract class QueryNode : AstNode
	{
		public abstract SelectColumn[] GetColumns();
	}
}