namespace NQuery.Compilation
{
	public abstract class TableReference : AstNode
	{
	}
}