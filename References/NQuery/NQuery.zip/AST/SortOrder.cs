namespace NQuery.Compilation
{
	public enum SortOrder
	{
		Ascending,
		Descending
	}
}